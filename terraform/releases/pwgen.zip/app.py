from pwgen import pwgen
import json

def lambda_handler(event, context):
    passwd = pwgen(24,
            symbols=True,
            )
    return {
            'statusCode': 200,
            'headers': { 'Content-Type': 'application/text'  },
            'body': json.dumps({
                'value': passwd
                })
            }

